package br.com.zup.mercadolivre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MercadoLivreApplicationTests {

	@Test
	void contextLoads() {
	}

}
